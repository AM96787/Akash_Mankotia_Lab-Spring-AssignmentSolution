package com.greatlearning.SpringBootStudentApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootStudentAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
